import { base44 } from './base44Client';


export const dailyDigest = base44.functions.dailyDigest;

export const workflowNotifications = base44.functions.workflowNotifications;

export const calendarFeed = base44.functions.calendarFeed;
