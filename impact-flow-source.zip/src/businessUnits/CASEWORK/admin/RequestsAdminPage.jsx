import React from "react";
import RequestsPanel from "./RequestsPanel.jsx";

export default function RequestsAdminPage() {
    return <RequestsPanel />;
}
