import React from "react";
import UsersPanel from "./UsersPanel.jsx";

export default function UsersAdminPage() {
    return <UsersPanel />;
}
