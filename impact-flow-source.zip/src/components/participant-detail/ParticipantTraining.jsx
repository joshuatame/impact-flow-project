export { default } from "@/businessUnits/CASEWORK/components/participants/ParticipantTraining.jsx";
export * from "@/businessUnits/CASEWORK/components/participants/ParticipantTraining.jsx";
