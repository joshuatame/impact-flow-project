export { default } from "@/businessUnits/CASEWORK/components/lsir/AssessmentComparison.jsx";
export * from "@/businessUnits/CASEWORK/components/lsir/AssessmentComparison.jsx";
