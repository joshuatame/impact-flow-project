import React from "react";

export default function DexTab() {
    return <div className="p-4 text-slate-300">DEX tab (CASEWORK only)</div>;
}
