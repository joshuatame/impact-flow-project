import React from "react";

export default function PdfTab() {
    return <div className="p-4 text-slate-300">PDFs tab (next step)</div>;
}
