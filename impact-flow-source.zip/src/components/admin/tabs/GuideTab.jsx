import React from "react";

export default function GuideTab() {
    return <div className="p-4 text-slate-300">Guide tab (next step)</div>;
}
