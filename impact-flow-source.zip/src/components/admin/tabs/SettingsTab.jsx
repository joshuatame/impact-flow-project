export { default } from "./SetingsTab.jsx";
export * from "./SetingsTab.jsx";
