import React from "react";

export default function ReportsExportsTab() {
    return <div className="p-4 text-slate-300">Reports/Exports tab (next step)</div>;
}
