import React from "react";

export default function SettingsTab() {
    return <div className="p-4 text-slate-300">Settings tab (next step)</div>;
}
