﻿import React from "react";
import RequestsPanelBase from "@/businessUnits/_shared/admin/RequestsPanelBase.jsx";
export default function RequestsPanel() {
    return <RequestsPanelBase />;
}
