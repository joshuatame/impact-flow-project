import React from "react";

export default function BulkUploadTab() {
    return <div className="p-4 text-slate-300">Bulk Upload tab (next step)</div>;
}
