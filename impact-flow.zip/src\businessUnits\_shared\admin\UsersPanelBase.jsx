// src/businessUnits/_shared/admin/UsersPanelBase.jsx
import React, { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getActiveEntity } from "@/lib/activeEntity";
import { collection, getDocs, query, where, addDoc, updateDoc, doc, serverTimestamp } from "firebase/firestore";
import { db } from "@/firebase";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserPlus, ShieldCheck, Trash2, RefreshCw } from "lucide-react";

import {
    allowedAssignableRoles,
    canAssignRole,
    canInviteUsers,
    getActorUnitRole,
} from "./roles";

function normEmail(v = "") {
    return String(v || "").trim().toLowerCase();
}

async function fetchAllUsers() {
    const snap = await getDocs(collection(db, "User"));
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
}

async function fetchInvites(entityId) {
    const qRef = query(collection(db, "userInvites"), where("entity_id", "==", entityId), where("status", "==", "Pending"));
    const snap = await getDocs(qRef);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
}

export default function UsersPanelBase() {
    const queryClient = useQueryClient();
    const active = useMemo(() => getActiveEntity(), []);
    const entityId = active?.id || "";

    const { data: me } = useQuery({
        queryKey: ["currentUser"],
        queryFn: () => base44.auth.me(),
    });

    const myUnitRole = useMemo(() => getActorUnitRole(me, entityId), [me, entityId]);
    const canInvite = useMemo(() => canInviteUsers(me, entityId), [me, entityId]);
    const assignableRoles = useMemo(() => allowedAssignableRoles(me, entityId), [me, entityId]);

    const { data: allUsers = [], isLoading: loadingUsers, refetch: refetchUsers } = useQuery({
        queryKey: ["unitUsers", entityId],
        enabled: !!entityId,
        queryFn: fetchAllUsers,
    });

    const { data: invites = [], isLoading: loadingInvites, refetch: refetchInvites } = useQuery({
        queryKey: ["unitInvites", entityId],
        enabled: !!entityId,
        queryFn: () => fetchInvites(entityId),
    });

    const unitUsers = useMemo(() => {
        if (!entityId) return [];
        return (allUsers || []).filter((u) => u?.entity_access?.[entityId]?.active === true);
    }, [allUsers, entityId]);

    // Invite dialog
    const [inviteOpen, setInviteOpen] = useState(false);
    const [inviteForm, setInviteForm] = useState({ email: "", full_name: "", role: "User" });

    const createInvite = useMutation({
        mutationFn: async () => {
            const email = normEmail(inviteForm.email);
            if (!email) throw new Error("Email required");
            if (!canAssignRole(me, entityId, inviteForm.role)) throw new Error("Not allowed to assign that role");

            await addDoc(collection(db, "userInvites"), {
                email,
                full_name: (inviteForm.full_name || "").trim(),
                entity_id: entityId,
                role: inviteForm.role,
                status: "Pending",
                created_at: serverTimestamp(),
                created_by: me?.id || null,
            });
        },
        onSuccess: async () => {
            setInviteOpen(false);
            setInviteForm({ email: "", full_name: "", role: "User" });
            await refetchInvites();
        },
    });

    const updateUserAccess = useMutation({
        mutationFn: async ({ userId, role, active }) => {
            if (!userId) throw new Error("userId required");
            if (!canAssignRole(me, entityId, role)) throw new Error("Not allowed to assign that role");

            const patch = {};
            patch[`entity_access.${entityId}`] = { role, active: active !== false };

            await updateDoc(doc(db, "User", userId), patch);
        },
        onSuccess: async () => {
            await refetchUsers();
        },
    });

    const removeUserFromUnit = useMutation({
        mutationFn: async ({ userId }) => {
            if (!userId) throw new Error("userId required");
            // Remove access by setting active=false (keeps audit trail)
            const patch = {};
            patch[`entity_access.${entityId}`] = { role: "User", active: false };
            await updateDoc(doc(db, "User", userId), patch);
        },
        onSuccess: async () => {
            await refetchUsers();
        },
    });

    if (!entityId) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="p-4 text-slate-300">No active business unit selected.</CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-4">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-white">Users (Unit scoped)</CardTitle>
                    <div className="flex items-center gap-2">
                        <Button
                            variant="secondary"
                            className="bg-slate-800 hover:bg-slate-700 text-white"
                            onClick={() => {
                                refetchUsers();
                                refetchInvites();
                            }}
                            type="button"
                        >
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Refresh
                        </Button>

                        {canInvite && (
                            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setInviteOpen(true)} type="button">
                                <UserPlus className="h-4 w-4 mr-2" />
                                Invite user
                            </Button>
                        )}
                    </div>
                </CardHeader>

                <CardContent className="space-y-4">
                    <div className="text-xs text-slate-400">
                        Your unit role:{" "}
                        <span className="text-slate-200 font-medium">{myUnitRole || "�"}</span>
                        {" � "}
                        You can assign:{" "}
                        <span className="text-slate-200 font-medium">{assignableRoles.join(", ") || "�"}</span>
                    </div>

                    {(loadingUsers || loadingInvites) ? (
                        <div className="text-sm text-slate-400">Loading�</div>
                    ) : (
                        <>
                            <div>
                                <div className="text-sm text-slate-200 font-semibold mb-2">Active users in this unit</div>

                                {unitUsers.length ? (
                                    <Table>
                                        <TableHeader>
                                            <TableRow className="border-slate-800">
                                                <TableHead className="text-slate-400">Name</TableHead>
                                                <TableHead className="text-slate-400">Email</TableHead>
                                                <TableHead className="text-slate-400">Role</TableHead>
                                                <TableHead className="text-slate-400 text-right">Actions</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {unitUsers.map((u) => {
                                                const access = u?.entity_access?.[entityId] || {};
                                                return (
                                                    <TableRow key={u.id} className="border-slate-800">
                                                        <TableCell className="text-white font-medium">{u.full_name || "�"}</TableCell>
                                                        <TableCell className="text-slate-400">{u.email || "�"}</TableCell>
                                                        <TableCell>
                                                            <Badge className="bg-slate-500/10 text-slate-200">{access.role || "User"}</Badge>
                                                        </TableCell>

                                                        <TableCell className="text-right">
                                                            <div className="inline-flex items-center gap-2">
                                                                <Select
                                                                    value={access.role || "User"}
                                                                    onValueChange={(role) =>
                                                                        updateUserAccess.mutate({ userId: u.id, role, active: true })
                                                                    }
                                                                    disabled={!canAssignRole(me, entityId, "User")} // quick gate; deeper check happens in mutation
                                                                >
                                                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white h-8 w-[200px]">
                                                                        <SelectValue />
                                                                    </SelectTrigger>
                                                                    <SelectContent className="bg-slate-800 border-slate-700">
                                                                        {["GeneralManager", "Manager", "ContractManager", "User"].map((r) => (
                                                                            <SelectItem key={r} value={r} className="text-white" disabled={!canAssignRole(me, entityId, r)}>
                                                                                {r}
                                                                            </SelectItem>
                                                                        ))}
                                                                    </SelectContent>
                                                                </Select>

                                                                <Button
                                                                    variant="destructive"
                                                                    className="bg-red-600 hover:bg-red-700 h-8"
                                                                    onClick={() => {
                                                                        const ok = window.confirm(`Remove ${u.email || "this user"} from this unit?`);
                                                                        if (ok) removeUserFromUnit.mutate({ userId: u.id });
                                                                    }}
                                                                    type="button"
                                                                >
                                                                    <Trash2 className="h-4 w-4" />
                                                                </Button>
                                                            </div>
                                                        </TableCell>
                                                    </TableRow>
                                                );
                                            })}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-slate-300 text-sm">
                                        No active users allocated to this business unit yet.
                                    </div>
                                )}
                            </div>

                            <div>
                                <div className="text-sm text-slate-200 font-semibold mb-2">Pending invites</div>
                                {invites.length ? (
                                    <Table>
                                        <TableHeader>
                                            <TableRow className="border-slate-800">
                                                <TableHead className="text-slate-400">Email</TableHead>
                                                <TableHead className="text-slate-400">Name</TableHead>
                                                <TableHead className="text-slate-400">Role</TableHead>
                                                <TableHead className="text-slate-400">Status</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {invites.map((i) => (
                                                <TableRow key={i.id} className="border-slate-800">
                                                    <TableCell className="text-white">{i.email}</TableCell>
                                                    <TableCell className="text-slate-300">{i.full_name || "�"}</TableCell>
                                                    <TableCell>
                                                        <Badge className="bg-blue-500/10 text-blue-300">{i.role || "User"}</Badge>
                                                    </TableCell>
                                                    <TableCell className="text-slate-400">Pending</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className="text-sm text-slate-400">No pending invites.</div>
                                )}
                            </div>
                        </>
                    )}
                </CardContent>
            </Card>

            <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
                <DialogContent className="bg-slate-900 border-slate-800">
                    <DialogHeader>
                        <DialogTitle className="text-white flex items-center gap-2">
                            <ShieldCheck className="h-4 w-4" />
                            Invite user to this business unit
                        </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-3 mt-2">
                        <div>
                            <div className="text-xs text-slate-300 mb-1">Email *</div>
                            <Input
                                value={inviteForm.email}
                                onChange={(e) => setInviteForm((p) => ({ ...p, email: e.target.value }))}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="name@company.com"
                            />
                        </div>

                        <div>
                            <div className="text-xs text-slate-300 mb-1">Full name (optional)</div>
                            <Input
                                value={inviteForm.full_name}
                                onChange={(e) => setInviteForm((p) => ({ ...p, full_name: e.target.value }))}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="Jane Doe"
                            />
                        </div>

                        <div>
                            <div className="text-xs text-slate-300 mb-1">Role</div>
                            <Select value={inviteForm.role} onValueChange={(role) => setInviteForm((p) => ({ ...p, role }))}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-800 border-slate-700">
                                    {["GeneralManager", "Manager", "ContractManager", "User"].map((r) => (
                                        <SelectItem key={r} value={r} className="text-white" disabled={!canAssignRole(me, entityId, r)}>
                                            {r}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <div className="text-[11px] text-slate-500 mt-1">
                                Invite is applied automatically when they log in the first time.
                            </div>
                        </div>

                        <Button
                            className="w-full bg-blue-600 hover:bg-blue-700"
                            onClick={() => createInvite.mutate()}
                            disabled={createInvite.isPending}
                            type="button"
                        >
                            {createInvite.isPending ? "Inviting�" : "Create invite"}
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
