import React from "react";

export default function SurveysTab() {
    return <div className="p-4 text-slate-300">Surveys tab (next step)</div>;
}
