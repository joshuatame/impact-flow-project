﻿import React from "react";
import PageHeader from "@/components/ui/PageHeader.jsx";
import { Shield, Database, Users, ClipboardList, FileText, Upload, Mail, Settings, BookOpen } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import SystemAdminLinks from "@/components/admin/SystemAdminLinks.jsx"; // ✅ ADD THIS

import UsersPanel from "./UsersPanel.jsx";
import RequestsPanel from "./RequestsPanel.jsx";
import SettingsPanel from "./SettingsPanel.jsx";
import EmailsPanel from "./EmailsPanel.jsx";

export default function CaseworkAdminPage() {
    return (
        <div className="p-4 md:p-8 space-y-6">
            <PageHeader title="Admin" subtitle="CASEWORK business unit administration" icon={Shield} />

            <SystemAdminLinks />

            <Tabs defaultValue="users" className="w-full">
                <TabsList className="bg-slate-900/50 border border-slate-800">
                    <TabsTrigger value="users" className="data-[state=active]:bg-slate-800">
                        <Users className="h-4 w-4 mr-2" /> Users
                    </TabsTrigger>

                    <TabsTrigger value="requests" className="data-[state=active]:bg-slate-800">
                        <ClipboardList className="h-4 w-4 mr-2" /> Requests
                    </TabsTrigger>

                    {/* ✅ CASEWORK ONLY */}
                    <TabsTrigger value="dex" className="data-[state=active]:bg-slate-800">
                        <Database className="h-4 w-4 mr-2" /> DEX
                    </TabsTrigger>

                    <TabsTrigger value="reports" className="data-[state=active]:bg-slate-800">
                        <Database className="h-4 w-4 mr-2" /> Reports/Exports
                    </TabsTrigger>

                    <TabsTrigger value="surveys" className="data-[state=active]:bg-slate-800">
                        <ClipboardList className="h-4 w-4 mr-2" /> Surveys
                    </TabsTrigger>

                    <TabsTrigger value="pdfs" className="data-[state=active]:bg-slate-800">
                        <FileText className="h-4 w-4 mr-2" /> PDFs
                    </TabsTrigger>

                    <TabsTrigger value="bulk" className="data-[state=active]:bg-slate-800">
                        <Upload className="h-4 w-4 mr-2" /> Bulk Upload
                    </TabsTrigger>

                    <TabsTrigger value="emails" className="data-[state=active]:bg-slate-800">
                        <Mail className="h-4 w-4 mr-2" /> Emails
                    </TabsTrigger>

                    <TabsTrigger value="settings" className="data-[state=active]:bg-slate-800">
                        <Settings className="h-4 w-4 mr-2" /> Settings
                    </TabsTrigger>

                    <TabsTrigger value="intakes" className="data-[state=active]:bg-slate-800">
                        <BookOpen className="h-4 w-4 mr-2" /> Intakes
                    </TabsTrigger>

                    <TabsTrigger value="guide" className="data-[state=active]:bg-slate-800">
                        <FileText className="h-4 w-4 mr-2" /> Guide
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="users"><UsersPanel /></TabsContent>
                <TabsContent value="requests"><RequestsPanel /></TabsContent>

                <TabsContent value="dex">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        DEX tools go here (CASEWORK only). We’ll move your existing DEX section from the old Admin.jsx into this tab.
                    </div>
                </TabsContent>

                <TabsContent value="reports">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        Reports/Exports (unit-scoped)
                    </div>
                </TabsContent>

                <TabsContent value="surveys">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        Surveys (unit-scoped)
                    </div>
                </TabsContent>

                <TabsContent value="pdfs">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        PDFs (unit-scoped)
                    </div>
                </TabsContent>

                <TabsContent value="bulk">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        Bulk Upload (unit-scoped)
                    </div>
                </TabsContent>

                <TabsContent value="emails">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        <EmailsPanel />
                    </div>
                </TabsContent>

                <TabsContent value="settings"><SettingsPanel /></TabsContent>

                <TabsContent value="intakes">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        Intakes (unit-scoped)
                    </div>
                </TabsContent>

                <TabsContent value="guide">
                    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
                        Guide (unit-scoped)
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}
