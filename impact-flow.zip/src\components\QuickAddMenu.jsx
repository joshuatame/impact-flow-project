import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
    Plus,
    Briefcase,
    GraduationCap,
    FileText,
    DollarSign,
    CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const quickActions = [
    {
        name: "Case Note",
        icon: FileText,
        page: "CaseNoteForm",
        color: "from-violet-500 to-purple-600",
    },
    {
        name: "Funding",
        icon: DollarSign,
        page: "FundingForm",
        color: "from-pink-500 to-rose-600",
    },
    {
        name: "Training",
        icon: GraduationCap,
        page: "TrainingForm",
        color: "from-amber-500 to-orange-600",
    },
    {
        name: "Bulk Training Complete",
        icon: CheckCircle2,
        page: "TrainingBulkComplete",
        color: "from-sky-500 to-cyan-600",
    },
    {
        name: "Employment",
        icon: Briefcase,
        page: "EmploymentForm",
        color: "from-emerald-500 to-green-600",
    },
];

export default function QuickAddMenu() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="relative">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className={cn(
                    "flex items-center gap-2 px-4 py-3 rounded-xl transition-all duration-200",
                    "text-slate-400 hover:text-white hover:bg-slate-800/50",
                    isOpen && "bg-blue-600/20 text-blue-400"
                )}
                type="button"
            >
                <Plus className={cn("h-5 w-5 transition-transform", isOpen && "rotate-45")} />
                <span className="font-medium">Add New</span>
            </button>

            {isOpen && (
                <>
                    <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
                    <div className="absolute left-0 top-full mt-2 z-50 w-56 bg-slate-900 border border-slate-800 rounded-xl shadow-xl overflow-hidden">
                        {quickActions.map((action) => (
                            <Link
                                key={action.name}
                                to={createPageUrl(action.page)}
                                onClick={() => setIsOpen(false)}
                                className="flex items-center gap-3 px-4 py-3 hover:bg-slate-800/50 transition-colors"
                            >
                                <div className={cn("p-1.5 rounded-lg bg-gradient-to-br", action.color)}>
                                    <action.icon className="h-4 w-4 text-white" />
                                </div>
                                <span className="text-white text-sm">{action.name}</span>
                            </Link>
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}
