import React from "react";
import UsersPanelBase from "@/businessUnits/_shared/admin/UsersPanelBase.jsx";
export default function UsersPanel() {
    return <UsersPanelBase />;
}
