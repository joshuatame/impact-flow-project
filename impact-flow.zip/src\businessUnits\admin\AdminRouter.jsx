﻿// src/pages/AdminRouter.jsx
import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getActiveEntity } from "@/lib/activeEntity";
import CaseworkAdminPage from "@/businessUnits/CASEWORK/admin/CaseworkAdminPage.jsx";
import ProgramsAdminPage from "@/businessUnits/PROGRAMS/admin/ProgramsAdminPage.jsx";
import RtoAdminPage from "@/businessUnits/RTO/admin/RtoAdminPage.jsx";
import LabourHireAdminPage from "@/businessUnits/LABOURHIRE/admin/LabourHireAdminPage.jsx";

function getUnitRole(me, entityId) {
    if (!me?.id || !entityId) return null;
    if (me.app_role === "SystemAdmin") return "SystemAdmin";
    return me?.entity_access?.[entityId]?.role || null;
}

function canSeeAdmin(me, entityId) {
    const r = getUnitRole(me, entityId);
    return r === "SystemAdmin" || r === "GeneralManager" || r === "Manager" || r === "ContractManager";
}

export default function AdminRouter() {
    const active = useMemo(() => getActiveEntity(), []);
    const entityId = active?.id || "";
    const entityType = String(active?.type || "").toUpperCase();

    const { data: me, isLoading } = useQuery({
        queryKey: ["currentUser"],
        queryFn: () => base44.auth.me(),
    });

    if (isLoading) return <div className="p-6 text-slate-300">Loading…</div>;

    if (!entityId) {
        return <div className="p-6 text-slate-300">No active business unit selected.</div>;
    }

    if (!canSeeAdmin(me, entityId)) {
        return (
            <div className="p-6 text-slate-300">
                You do not have permission to view Admin for this business unit.
            </div>
        );
    }

    switch (entityType) {
        case "CASEWORK":
            return (
                <>
                   
                    <CaseworkAdminPage />
                </>
            );
        case "PROGRAMS":
            return (
                <>
                  
                    <ProgramsAdminPage />
                </>
            );
        case "RTO":
            return (
                <>
                   
                    <RtoAdminPage />
                </>
            );
        case "LABOURHIRE":
            return (
                <>
                  
                    <LabourHireAdminPage />
                </>
            );
        default:
            return (
                <div className="p-6 text-slate-300">
                  
                    Unknown business unit type: {entityType || "—"}
                </div>
            );
    }
}
