import React from "react";

export default function SettingsPanel() {
    return (
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-slate-300">
            PROGRAMS SettingsPanel (unit settings + admin toggles go here)
        </div>
    );
}
