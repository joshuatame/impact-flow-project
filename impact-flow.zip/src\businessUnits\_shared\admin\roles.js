// src/businessUnits/_shared/admin/roles.js
export const UNIT_ROLES = ["GeneralManager", "Manager", "ContractManager", "User"];

const RANK = {
    SystemAdmin: 999,
    GeneralManager: 300,
    Manager: 200,
    ContractManager: 100,
    User: 0,
};

export function getActorUnitRole(me, entityId) {
    if (!me?.id || !entityId) return null;
    if (me.app_role === "SystemAdmin") return "SystemAdmin";
    return me?.entity_access?.[entityId]?.role || null;
}

export function canSeeAdmin(me, entityId) {
    const r = getActorUnitRole(me, entityId);
    return r === "SystemAdmin" || r === "GeneralManager" || r === "Manager" || r === "ContractManager";
}

export function canInviteUsers(me, entityId) {
    const r = getActorUnitRole(me, entityId);
    return r === "SystemAdmin" || r === "GeneralManager";
}

export function canCreateRequests(me, entityId) {
    const r = getActorUnitRole(me, entityId);
    return r === "SystemAdmin" || r === "GeneralManager" || r === "Manager";
}

export function canApproveRequests(me, entityId) {
    const r = getActorUnitRole(me, entityId);
    return r === "SystemAdmin" || r === "GeneralManager";
}

export function canAssignRole(me, entityId, targetRole) {
    const actor = getActorUnitRole(me, entityId);
    if (!actor) return false;

    if (actor === "SystemAdmin") return true;

    const actorRank = RANK[actor] ?? -1;
    const targetRank = RANK[targetRole] ?? -1;

    // Must be strictly below actor
    return targetRank < actorRank;
}

export function allowedAssignableRoles(me, entityId) {
    const roles = ["GeneralManager", "Manager", "ContractManager", "User"];
    return roles.filter((r) => canAssignRole(me, entityId, r));
}
