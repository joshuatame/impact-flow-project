import React from "react";

export default function EmailsTab() {
    return <div className="p-4 text-slate-300">Emails tab (next step)</div>;
}
