﻿// src/pages/index.jsx
import React from "react";
import { Routes, Route, Outlet, useLocation } from "react-router-dom";

import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";
import Participants from "./Participants";
import Programs from "./Programs";
import ParticipantDetail from "./ParticipantDetail";
import ParticipantForm from "./ParticipantForm";
import ProgramForm from "./ProgramForm";
import ProgramDetail from "./ProgramDetail";
import CaseNoteForm from "./CaseNoteForm";
import SurveyForm from "./SurveyForm";
import Reports from "./Reports";
import Settings from "./Settings";
import CaseNoteDetail from "./CaseNoteDetail";
import FundingForm from "./FundingForm";
import SurveyBuilder from "./SurveyBuilder";
import WorkflowApprovals from "./WorkflowApprovals";
import ParticipantRequest from "./ParticipantRequest";
import TrainingForm from "./TrainingForm";
import TrainingBulkComplete from "./TrainingBulkComplete";
import EmploymentForm from "./EmploymentForm";
import Tasks from "./Tasks";
import Forum from "./Forum";
import ReportBuilder from "./ReportBuilder";
import LSIRReport from "./LSIRReport";
import EmployerAcademy from "./EmployerAcademy";
import EmployerDetail from "./EmployerDetail";
import EmployerForm from "./EmployerForm";
import ReportView from "./ReportView";
import Notifications from "./Notifications";
import CaseNotes from "./CaseNotes";
import Resources from "./Resources";
import SurveyTemplateForm from "./SurveyTemplateForm";
import Login from "./Login";
import OnboardingPending from "./OnboardingPending";
import RequireAuth from "@/components/auth/RequireAuth";
import RequireOnboarded from "@/components/auth/RequireOnboarded";
import RequireEntitySelected from "@/components/auth/RequireEntitySelected";
import PublicReply from "@/pages/PublicReply.jsx";

// ✅ new pages
import JobBlast from "./JobBlast";
import JobBlastApply from "./JobBlastApply";
import DocumentDesigner from "./DocumentDesigner";
import MonthlyReports from "./MonthlyReports";
import ProgramEmail from "./ProgramEmail";
import FinishSignIn from "./FinishSignIn.jsx";

import Landing from "./Landing";
import Launchpad from "./Launchpad";

// PDF Forms pages
import PdfForms from "./PdfForms";
import PdfFormFill from "./PdfFormFill";
import PdfTemplateAdmin from "./PdfTemplateAdmin";
import PdfPacketReview from "./PdfPacketReview";
import ManagerApprovalReview from "./ManagerApprovalReview";
import ResumeBuilder from "./ResumeBuilder";

// ✅ NEW: Admin router (business-unit specific admin pages)
import AdminRouter from "../businessUnits/admin/AdminRouter.jsx";
import BusinessEntitiesAdmin from "./BusinessEntitiesAdmin.jsx";

const PAGES = {
    Dashboard,
    Participants,
    Programs,
    ParticipantDetail,
    ParticipantForm,
    ProgramForm,
    ResumeBuilder,
    ProgramDetail,
    CaseNoteForm,
    SurveyForm,
    Reports,
    Settings,
    CaseNoteDetail,
    FundingForm,
    SurveyBuilder,
    WorkflowApprovals,
    ParticipantRequest,
    TrainingForm,
    EmploymentForm,
    Tasks,
    Forum,
    ReportBuilder,
    LSIRReport,
    EmployerAcademy,
    EmployerDetail,
    EmployerForm,
    ReportView,
    Notifications,
    CaseNotes,
    Resources,
    SurveyTemplateForm,
    BusinessEntitiesAdmin,
    JobBlast,
    DocumentDesigner,
    MonthlyReports,
    ProgramEmail,
    FinishSignIn,
    PdfForms,
    PdfFormFill,
    PdfTemplateAdmin,
    PdfPacketReview,
};

function getCurrentPageName(pathname) {
    let path = pathname;
    if (path.endsWith("/")) path = path.slice(0, -1);
    const last = path.split("/").pop() || "Dashboard";
    const match = Object.keys(PAGES).find((name) => name.toLowerCase() === last.toLowerCase());
    return match || "Dashboard";
}

function LayoutRouteWrapper() {
    const location = useLocation();
    const currentPageName = getCurrentPageName(location.pathname);

    return (
        <Layout currentPageName={currentPageName}>
            <Outlet />
        </Layout>
    );
}

function NoSidebarWrapper() {
    return <Outlet />;
}

export default function Pages() {
    return (
        <Routes>
            <Route path="/login" element={<Login />} />

            <Route path="/JobBlastApply" element={<JobBlastApply />} />
            <Route path="/job-apply" element={<JobBlastApply />} />
            <Route path="/reply" element={<PublicReply />} />

            <Route element={<RequireAuth />}>
                <Route element={<NoSidebarWrapper />}>
                    <Route path="/OnboardingPending" element={<OnboardingPending />} />
                </Route>

                <Route element={<RequireOnboarded />}>
                    <Route element={<NoSidebarWrapper />}>
                        <Route path="/" element={<Landing />} />
                        <Route path="/Landing" element={<Landing />} />
                        <Route path="/Launchpad" element={<Launchpad />} />
                    </Route>

                    <Route element={<RequireEntitySelected />}>
                        <Route element={<LayoutRouteWrapper />}>
                            <Route path="/Dashboard" element={<Dashboard />} />
                            <Route path="/BusinessEntitiesAdmin" element={<BusinessEntitiesAdmin />} />
                            <Route path="/Participants" element={<Participants />} />
                            <Route path="/Programs" element={<Programs />} />
                            <Route path="/ParticipantDetail" element={<ParticipantDetail />} />
                            <Route path="/ParticipantForm" element={<ParticipantForm />} />
                            <Route path="/ProgramForm" element={<ProgramForm />} />
                            <Route path="/ProgramDetail" element={<ProgramDetail />} />
                            <Route path="/CaseNoteForm" element={<CaseNoteForm />} />
                            <Route path="/SurveyForm" element={<SurveyForm />} />
                            <Route path="/Reports" element={<Reports />} />

                            {/* ✅ Business-unit specific Admin */}
                            <Route path="/Admin" element={<AdminRouter />} />

                            <Route path="/Settings" element={<Settings />} />
                            <Route path="/CaseNoteDetail" element={<CaseNoteDetail />} />
                            <Route path="/FundingForm" element={<FundingForm />} />
                            <Route path="/SurveyBuilder" element={<SurveyBuilder />} />
                            <Route path="/WorkflowApprovals" element={<WorkflowApprovals />} />
                            <Route path="/ParticipantRequest" element={<ParticipantRequest />} />
                            <Route path="/TrainingForm" element={<TrainingForm />} />
                            <Route path="/TrainingBulkComplete" element={<TrainingBulkComplete />} />
                            <Route path="/EmploymentForm" element={<EmploymentForm />} />
                            <Route path="/Tasks" element={<Tasks />} />
                            <Route path="/Forum" element={<Forum />} />
                            <Route path="/MonthlyReports" element={<MonthlyReports />} />
                            <Route path="/ReportBuilder" element={<ReportBuilder />} />
                            <Route path="/LSIRReport" element={<LSIRReport />} />
                            <Route path="/EmployerAcademy" element={<EmployerAcademy />} />
                            <Route path="/EmployerDetail" element={<EmployerDetail />} />
                            <Route path="/EmployerForm" element={<EmployerForm />} />
                            <Route path="/ReportView" element={<ReportView />} />
                            <Route path="/Notifications" element={<Notifications />} />
                            <Route path="/CaseNotes" element={<CaseNotes />} />
                            <Route path="/Resources" element={<Resources />} />

                            <Route path="/JobBlast" element={<JobBlast />} />
                            <Route path="/DocumentDesigner" element={<DocumentDesigner />} />
                            <Route path="/ProgramEmail" element={<ProgramEmail />} />

                            <Route path="/SurveyTemplateForm" element={<SurveyTemplateForm />} />
                            <Route path="/ResumeBuilder" element={<ResumeBuilder />} />

                            <Route path="/PdfForms" element={<PdfForms />} />
                            <Route path="/PdfFormFill" element={<PdfFormFill />} />
                            <Route path="/PdfTemplateAdmin" element={<PdfTemplateAdmin />} />
                            <Route path="/PdfPacketReview" element={<PdfPacketReview />} />
                            <Route path="/ManagerApprovalReview" element={<ManagerApprovalReview />} />
                        </Route>
                    </Route>
                </Route>
            </Route>
        </Routes>
    );
}