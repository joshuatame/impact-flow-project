import React from "react";

export default function UsersTab() {
    return <div className="p-4 text-slate-300">Users tab (next step)</div>;
}
