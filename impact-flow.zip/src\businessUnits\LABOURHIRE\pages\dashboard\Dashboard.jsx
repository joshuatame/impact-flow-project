// ================================
// File: LABOURHIRE/pages/dashboard/Dashboard.jsx
// ================================

import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQuery } from "@tanstack/react-query";
import { Users, Briefcase, FolderKanban, AlertCircle, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    LineChart,
    Line,
} from "recharts";
import StatsCard from "@/components/ui/StatsCard.jsx";
import PageHeader from "@/components/ui/PageHeader.jsx";
import LoadingSpinner from "@/components/ui/LoadingSpinner.jsx";
import { format, subDays } from "date-fns";

const CHART_TEXT_LH = "#ffffff";
const TOOLTIP_STYLE_LH = {
    backgroundColor: "#1e293b",
    border: "1px solid #334155",
    borderRadius: "12px",
    color: CHART_TEXT_LH,
};
const TOOLTIP_LABEL_STYLE_LH = { color: CHART_TEXT_LH };
const TOOLTIP_ITEM_STYLE_LH = { color: CHART_TEXT_LH };

export default function Dashboard() {
    const [user, setUser] = useState(null);

    useEffect(() => {
        loadUser();
    }, []);

    const loadUser = async () => {
        try {
            const userData = await base44.auth.me();
            setUser(userData);
        } catch {
            // ignore
        }
    };

    // LabourHire dashboard uses existing collections for now:
    // - Participant => Workers
    // - Employer => Clients
    // - EmploymentPlacement => Placements
    // - Task => Ops tasks
    // - FundingRecord => Spend (optional)
    const { data: workers = [], isLoading: loadingWorkers } = useQuery({
        queryKey: ["lh_workers"],
        queryFn: () => base44.entities.Participant.list("-created_date", 5000),
    });

    const { data: clients = [], isLoading: loadingClients } = useQuery({
        queryKey: ["lh_clients"],
        queryFn: () => base44.entities.Employer.list("-created_date", 2000),
    });

    const { data: placements = [], isLoading: loadingPlacements } = useQuery({
        queryKey: ["lh_placements"],
        queryFn: () => base44.entities.EmploymentPlacement.list("-created_date", 5000),
    });

    const { data: tasks = [], isLoading: loadingTasks } = useQuery({
        queryKey: ["lh_tasks"],
        queryFn: () => base44.entities.Task.list("-created_date", 3000),
    });

    const { data: fundingRecords = [], isLoading: loadingFunding } = useQuery({
        queryKey: ["lh_funding"],
        queryFn: () => base44.entities.FundingRecord.list("-created_date", 2000),
    });

    const isLoading = loadingWorkers || loadingClients || loadingPlacements || loadingTasks || loadingFunding;
    if (isLoading) return <LoadingSpinner />;

    const subtitleDate = format(new Date(), "EEEE, MMMM d, yyyy");

    const myOutstandingTasks = tasks.filter(
        (t) => t.assigned_to_id === user?.id && t.status !== "Completed" && t.status !== "Cancelled"
    );

    const activePlacements = placements.filter((p) => p.status === "Started" || p.status === "Sustained" || p.status === "Active");
    const displayPlacements = activePlacements.slice(0, 5);

    const spendByCategory = Object.entries(
        fundingRecords
            .filter((f) => f.record_type === "Expense")
            .reduce((acc, f) => {
                acc[f.category] = (acc[f.category] || 0) + (f.amount || 0);
                return acc;
            }, {})
    ).map(([name, value]) => ({ name, value }));

    const placementsStartedOverTime = Array.from({ length: 30 }, (_, i) => {
        const date = subDays(new Date(), 29 - i);
        const dateStr = format(date, "yyyy-MM-dd");

        const count = placements.filter((p) => {
            const d = p.start_date || p.created_date;
            if (!d) return false;
            return format(new Date(d), "yyyy-MM-dd") === dateStr && (p.status === "Started" || p.status === "Sustained" || p.status === "Active");
        }).length;

        return { date: format(date, "MMM d"), count };
    });

    return (
        <div className="p-4 md:p-8 pb-24 lg:pb-8">
            <PageHeader title="Labour Hire Dashboard" subtitle={`${subtitleDate}${myOutstandingTasks.length ? `  ${myOutstandingTasks.length} outstanding` : ""}`}>
                <Link to={createPageUrl("Employers")}>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                        <FolderKanban className="h-4 w-4 mr-2" />
                        View Clients
                    </Button>
                </Link>
            </PageHeader>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <StatsCard title="Workers" value={workers.length} icon={Users} gradient="from-blue-500 to-cyan-500" />
                <StatsCard title="Clients" value={clients.length} icon={FolderKanban} gradient="from-violet-500 to-purple-500" />
                <StatsCard title="Active Placements" value={activePlacements.length} icon={Briefcase} gradient="from-emerald-500 to-green-500" />
                <StatsCard title="Outstanding Tasks" value={myOutstandingTasks.length} icon={AlertCircle} gradient="from-amber-500 to-orange-500" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div className="bg-slate-900/50 border border-slate-800/50 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Placements Started (Last 30 Days)</h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={placementsStartedOverTime}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis
                                    dataKey="date"
                                    stroke={CHART_TEXT_LH}
                                    tick={{ fill: CHART_TEXT_LH }}
                                    fontSize={12}
                                    tickLine={false}
                                    interval="preserveStartEnd"
                                />
                                <YAxis stroke={CHART_TEXT_LH} tick={{ fill: CHART_TEXT_LH }} fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip contentStyle={TOOLTIP_STYLE_LH} labelStyle={TOOLTIP_LABEL_STYLE_LH} itemStyle={TOOLTIP_ITEM_STYLE_LH} />
                                <Line type="monotone" dataKey="count" stroke="#10b981" strokeWidth={2} dot={false} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800/50 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Spending by Category</h3>
                    {spendByCategory.length > 0 ? (
                        <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={spendByCategory} layout="vertical">
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                                    <XAxis
                                        type="number"
                                        stroke={CHART_TEXT_LH}
                                        tick={{ fill: CHART_TEXT_LH }}
                                        fontSize={12}
                                        tickFormatter={(v) => `$${v}`}
                                    />
                                    <YAxis
                                        type="category"
                                        dataKey="name"
                                        stroke={CHART_TEXT_LH}
                                        tick={{ fill: CHART_TEXT_LH }}
                                        fontSize={11}
                                        width={90}
                                        tickLine={false}
                                    />
                                    <Tooltip
                                        contentStyle={TOOLTIP_STYLE_LH}
                                        labelStyle={TOOLTIP_LABEL_STYLE_LH}
                                        itemStyle={TOOLTIP_ITEM_STYLE_LH}
                                        formatter={(value) => [`$${Number(value).toLocaleString()}`, "Amount"]}
                                    />
                                    <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    ) : (
                        <div className="text-center py-8 text-slate-500">No expenses recorded</div>
                    )}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800/50 rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Active Placements</h3>
                        <Link to={createPageUrl("EmploymentPlacements")}>
                            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                                View All
                                <ChevronRight className="h-4 w-4 ml-1" />
                            </Button>
                        </Link>
                    </div>

                    <div className="space-y-3">
                        {displayPlacements.map((p) => (
                            <Link
                                key={p.id}
                                to={createPageUrl(`EmploymentPlacementDetail?id=${p.id}`)}
                                className="flex items-center justify-between p-3 rounded-xl bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                            >
                                <div>
                                    <p className="font-medium text-white">{p.position_title || p.role_title || "Placement"}</p>
                                    <p className="text-sm text-slate-400">{p.employer_name || p.company_name || p.site_location || "�"}</p>
                                </div>
                                <Badge className="bg-slate-700/50 text-slate-300">{p.status || "Active"}</Badge>
                            </Link>
                        ))}

                        {displayPlacements.length === 0 && <div className="text-center py-8 text-slate-500">No active placements</div>}
                    </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800/50 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Operations</h3>
                    <div className="space-y-3 text-slate-300">
                        <div className="p-3 rounded-xl bg-slate-800/30">
                            <div className="text-sm text-slate-400">Outstanding tasks assigned to you</div>
                            <div className="text-2xl font-bold text-white">{myOutstandingTasks.length}</div>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-800/30">
                            <div className="text-sm text-slate-400">Total placements</div>
                            <div className="text-2xl font-bold text-white">{placements.length}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}