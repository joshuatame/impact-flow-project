﻿import React from "react";
import ProgramAdminPage from "@/businessUnits/PROGRAMS/admin/ProgramsAdminPage.jsx";
import SystemAdminLinks from "@/components/admin/SystemAdminLinks.jsx"; // ✅ ADD THIS
// For now identical tab set; you can diverge later without changing routing.
export default function RtoAdminPage() {
    return <ProgramAdminPage />;
    <SystemAdminLinks />
}
