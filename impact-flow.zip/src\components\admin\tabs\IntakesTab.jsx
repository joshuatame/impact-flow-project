import React from "react";

export default function IntakesTab() {
    return <div className="p-4 text-slate-300">Intakes tab (next step)</div>;
}
