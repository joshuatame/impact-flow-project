// src/businessUnits/sidebars/LabourhireSidebar.jsx
import React from "react";
import { LayoutDashboard, Building2, FileText, FolderOpen } from "lucide-react";

export const LABOURHIRE_SIDEBAR_ID = "LABOURHIRE";

export default function LabourhireSidebar() {
    return null;
}

export const labourhireNavItems = [
    { name: "Dashboard", icon: LayoutDashboard, page: "Dashboard" },
    { name: "Employers", icon: Building2, page: "EmployerAcademy" },
    { name: "Reports", icon: FileText, page: "Reports" },
    { name: "Resources", icon: FolderOpen, page: "Resources" },
];
